from django.shortcuts import render, redirect
from .models import company
import datetime
from django.http import HttpResponse
def save_in_admin(request,pk):
    if pk=="message":
        name = request.POST["name"]
        email = request.POST["email"]
        message = request.POST["message"]

        f = company(name=name,email=email,address=message,account_number="not seen")
        f.save(using="default")
        return redirect("/")
def show_message(request):
    if request.user.is_superuser:
        html = "<table style='width:60%;margin:auto;text-align:center'><tr><th>Name</th><th>Email</th><th>Message</th><th>Seen</th></tr>"
        for a in company.objects.all().order_by("-id").order_by("account_number"):
            html += f"<tr><td>{a.name}</td><td>{a.email}</td><td>{a.address}</td><td>{a.account_number}</td></tr>"
        html += "</table>"
        return HttpResponse(html)
    return redirect("/")


