from django.contrib import admin
from .models import templates,user_info,currency,currency_rate

# Register your models here.
admin.site.register(templates)
admin.site.register(user_info)
admin.site.register(currency)
admin.site.register(currency_rate)

